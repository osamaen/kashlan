<?php

namespace App\Models;


class AboutTranslation extends TransModel
{
    //
}
