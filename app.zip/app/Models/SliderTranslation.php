<?php

namespace App\Models;


class SliderTranslation extends TransModel
{
    //
}
