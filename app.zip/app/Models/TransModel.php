<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransModel extends Model
{
    protected $guarded = [];
    public $timestamps = false;
}
