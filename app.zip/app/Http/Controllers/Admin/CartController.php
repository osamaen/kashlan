<?php

namespace App\Http\Controllers\Admin;

use App\Models\Cart;
use App\Http\Requests\StoreCartRequest;
use App\Http\Requests\UpdateCartRequest;

class CartController extends AdminController
{
   
    public function index()
    {
       
    }


  
    public function update(UpdateCartRequest $request, Cart $cart)
    {
      
    }


}
