<div class="container-fluid banner  my-5 parallax-section" data-aos="fade-up" style="height:700px;background-image:url('{{ asset('bunner.jpg')}}') " >
    <div class="container py-5">
        <div class="row g-4 align-items-center">
            <div class="col-lg-6">
                <div class="py-4">
                    <h1 class="display-3 text-white"></h1>
                    <p class="fw-normal display-3 text-dark mb-4"></p>
                    <p class="mb-4 text-dark"></p>
                  
                </div>
            </div>
            <div class="col-lg-6">
                <div class="position-relative">
                    <img src="" class="img-fluid w-100 rounded" alt="">
                  
                </div>
            </div>
        </div>
    </div>
</div>