<style>

.container-fluid .row {
        --bs-gutter-x: 1.5rem;
    }

    .container-fluid .img-fluid {
        object-fit: cover;
        height: 100%;
    }

    .container-fluid .h-100 {
        height: 100%;
    }

    .container-fluid .w-100 {
        width: 100%;
    }
</style>





<div class="container-fluid fruite py-5  " style="    background-color: #f6f6f6">
    <div class="container">
        <div class="tab-class text-center">
            <div class="row g-4">
                <div class="col-lg-12 text-center mb-5">
                    <h1 class="text-primary" style="font-family: unset ; font-weight:300;color:black !important" >
                        {{ trans('frontend.brand_portfolio') }}</h1>
                </div>

            </div>
            <div id="portfolioId" class="carousel slide position-relative" data-bs-ride="carousel">

                <div style="height: 100% !important ;width:100%" class="carousel-inner" role="listbox">
            <div class="row">
                <div class="col-6">
                    <div class="d-flex flex-column gap-4">
                        <div class="d-flex flex-row gap-4" style="flex: 1;">
                            <div class="d-flex flex-column gap-4" style="flex: 1;">
                                <img src="{{ asset('55djpg.jpg') }}" class="rounded img-fluid" alt="">
                                <img src="{{ asset('6.jpg') }}" class="rounded img-fluid" alt="">
                            </div>
                            <div style="flex: 1;">
                                <img src="{{ asset('4djpg.jpg') }}" class="rounded img-fluid h-100" alt="">
                            </div>
                        </div>
                        <div>
                            <img src="{{ asset('555588899djpg.jpg') }}" class="rounded img-fluid w-100" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-6">
                    <img src="{{ asset('big.jpg') }}" class="img-fluid rounded w-100 h-100" alt="">
                </div>
            </div>
           
            <button
            style="    opacity: 1;
                    background: white;
                }"
            class="carousel-control-prev" type="button" data-bs-target="#portfolioId" data-bs-slide="prev">
            <i class="fas fa-chevron-left" style="color: black"></i>
            <span class="visually-hidden">Previous</span>
        </button>
        <button style="    opacity: 1;
        background: white;
                }"
            class="carousel-control-next" type="button" data-bs-target="#portfolioId" data-bs-slide="next">
            <i class="fas fa-chevron-right" style="color: black"></i>
            <span class="visually-hidden">Next</span>
        </button>
        </div>

    </div></div>

</div>
</div>


</div>
