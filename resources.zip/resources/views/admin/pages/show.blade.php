@extends('layouts.admin.app')

@section('content')
 

            <div class="card-body py-3">

                <form class="form-horizontal form" role="form">

                    @yield('form-inputs')


                </form>
                <div>

                </div>

            </div>

        </div>

    </div>

    </div>
@endsection

@push('js')
@endpush
