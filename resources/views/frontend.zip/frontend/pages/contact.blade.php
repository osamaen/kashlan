
@extends('layouts.frontend.app')
@section('content')

        <div class="container-fluid contact py-5">
            <div class="container py-5">
                <div class="p-5 bg-light rounded">
                    <div class="row g-4">
                        <div class="col-12">
                
                        </div>
                        <div class="col-lg-12">
                            <div class="h-100 rounded">
                                {!! $contacts->map !!}
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <form action="" class="">
                                <div class="row">
                                    <div class="col-6">
                                <input type="text" class="form-control border-0 py-3 mb-4" placeholder="{{trans('frontend.Your_Name')}}">
                            </div>
                               
                            <div class="col-6">
                                <input type="text" class="form-control border-0 py-3 mb-4" placeholder="{{trans('frontend.Your_Name')}}">
                            </div></div>
                                <input type="email" class="w-100 form-control border-0 py-3 mb-4" placeholder="{{trans('frontend.Your_Email')}}">
                                <input type="phone" class="w-100 form-control border-0 py-3 mb-4" placeholder="{{trans('frontend.phone')}}">
                                <input type="subject" class="w-100 form-control border-0 py-3 mb-4" placeholder="{{trans('frontend.subject')}}">
                                <textarea class="w-100 form-control border-0 mb-4" rows="5" cols="10" placeholder="Your Message"></textarea>
                                <button class="w-100 btn form-control border-secondary py-3 bg-white text-primary " type="submit">
                                    {{trans('frontend.submit')}}
                                </button>
                            </form>
                        </div>
                        <div class="col-lg-5">
                            <div class="d-flex p-4 rounded mb-4 bg-white">
                                <i class="fas fa-map-marker-alt fa-2x text-primary me-4" style="margin-left: 1rem"></i>
                                <div>
                                
                                    <p class="mb-2"> {{$contacts->address}}</p>
                                </div>
                            </div>
                            <div class="d-flex p-4 rounded mb-4 bg-white">
                                <i class="fas fa-clock fa-2x text-primary me-4" style="margin-left: 1rem" ></i>
                                <div>
                                
                                    <p class="mb-2">{{$contacts->opening}}</p>
                                </div>
                            </div>
                            <div class="d-flex p-4 rounded mb-4 bg-white">
                                <i class="fas fa-envelope fa-2x text-primary me-4" style="margin-left: 1rem" ></i>
                                <div>
                                
                                    <p class="mb-2">{{$contacts->email}}</p>
                                </div>
                            </div>
                            <div class="d-flex p-4 rounded bg-white">
                                <i class="fa fa-phone-alt fa-2x text-primary me-4" style="margin-left: 1rem"></i>
                                <div>
                                    {{-- <h4>Telephone</h4> --}}
                                    <p>Fax: {{$contacts->fax}}<br>
                                        Phone: {{$contacts->phone}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  


@endsection