<div class="container-fluid text-white-50 footer pt-5 mt-5" style="background: #454648">
    <div class="container py-5">
        
        <div class="row g-5">
            <div class="col-lg-4 col-md-6 ">
                <div class="footer-item">
                    <h4 class="text-light mb-3">
                        <img alt="Logo" src="{{asset('logo-2.png')}}" class="h-50px logo" />
                    </h4>

                    <p class="mb-4">
                        typesetting, remaining essentially unchanged. It was
                        popung of 
                    </p>
                        <div class="d-flex justify-content-start pt-3 border-top-1" style="    border-top: 1px #9E9E9E solid;">
                            {{-- <a class="btn   me-2 btn-md-square " href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn  me-2 btn-md-square rounded-circle" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn  me-2 btn-md-square rounded-circle" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn  btn-md-square rounded-circle" href=""><i class="fab fa-linkedin-in"></i></a>
                       
                        --}}

                            @foreach ($socials as $social)
                            <a class="btn   me-2 btn-md-square " target="_blank" href="{{$social->link}}" style="color:white">{!! $social->icon !!}</a>
                            @endforeach
                       
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="footer-item">
                    <h3 class="text-light mb-5">{{trans('frontend.contacts')}}</h3>
                    <p> <i class="fas fa-map-marker-alt mx-2 text-white"></i>{{$contacts->address}}</p>
                    <p><i class="fa fa-phone-alt  mx-2 text-white" ></i>{{$contacts->phone}}</p>
                    <p><i class="fas fa-envelope mx-2 text-white" ></i>{{$contacts->email}}</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="d-flex flex-column text-start footer-item">
                    <h3 class="text-light mb-3">{{trans('frontend.newsletter')}}</h3>
                    <p class="mb-4">
                        {{trans('news_letters.text')}}
                        </p>
                    <input class="form-control"  name=""/>
            
                </div>
            </div>
       
        </div>
    </div>
</div>